function Sbvec = bvec(S,N)
    Sbvec=reshape(S,1,size(S,1)*size(S,2),[]);
end


%   SIGNAL_OP Package: Version 1.1
%   Jonathan J. Adams
%   Contact: adamsjonathan@ufl.edu