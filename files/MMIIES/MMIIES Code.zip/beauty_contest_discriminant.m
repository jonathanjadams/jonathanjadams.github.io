function D = beauty_contest_discriminant(tau_u,tau_v,alpha,varphi)
    D = varphi^4*tau_u^2*(1+tau_v)^2 + 18*tau_u^2*(1+tau_v)*(1+(1-alpha)*tau_v)*(1-alpha)*varphi^2 - 4*varphi^4*tau_u^3*(1+tau_v) - 4*tau_u*(1+(1-alpha)*tau_v)^3*(1-alpha)-27*tau_u^2*(1+tau_v)^2*(1-alpha)^2*varphi^2;
end

