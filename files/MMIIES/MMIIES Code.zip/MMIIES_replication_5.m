

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Macroeconomic Models with Incomplete Information and Endogenous Signals
%  
%                           Jonathan J. Adams
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This version: 5
% Date: 10/9/2023
% Contact: adamsjonathan@ufl.edu

% Dependencies: SIGNAL_OP Package of MATLAB functions, Version 1.3+ (add to path)
% MMIIES_beauty_contest, MMIIES_singleton, MMIIES_confoundingdynamics
% downloadable from jonathanjadams.com



clear all

version = 5;

plot_saving = 0; %switch to 1 to save plots in a subfolder "graphs"

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                Indeterminancy in the Beauty Contest Model
%                                (Figure 1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Additional ependencies: 
% beauty_contest_discriminant.m

MMIIES_beauty_contest

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    Solutions to the Singleton Model
%                           (Figures 2 and 3)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Additional dependencies:
% Matrix of results from the Nimark algorithm: 'nimark_pirfs.mat'
% Matrices of results from Han et al (2022) algorithm: 'ztran_singleton.mat', 'ztran_singleton_time.mat'

MMIIES_singleton


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               Instability in the Confounding Dynamics Model
%                                (Figure 4)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MMIIES_confoundingdynamics


