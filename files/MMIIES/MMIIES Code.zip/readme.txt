The MMIIES replicatiion package contains the following files.



Matlab code:

MMIIES_replication_5: This is the main replication file.  Use this file to reproduce the plots from the paper. All other files are dependencies or sub-dependencies.

MMIIES_beauty_contest: This file solves the indeterminacy regions in the beauty contest model.

MMIIES_singleton: This file compares solutions to the Singleton model

MMIIES_confoundingdynamics: This file computes perturbation divergence in the confounding dynamics model

MMIIES_singleton_ztran: This file solves the Singleton model with the Han et al (2022) z-tran toolbox; it produces the output fils "ztran_singleton" and "ztran_singleton_time"
This file does not need to be run to reproduce the paper figures.  But to make comparisons about algorithm solution times using your own computer, you will need to run this program.

beauty_contest_discriminant: sub-routine used in 'MMIIES_beauty_contest'



Folder:

SIGNAL_OP Package: subroutines for solving models by Signal Operator Iteration



Matrices:

nimark_pirfs: Impulse response functions from the Nimark algorithm (not publicly available)

ztran_singleton: Output of impulse response functions from "MMIIES_singleton_ztran"

ztran_singleton_time: Model solution time from "MMIIES_singleton_ztran"
