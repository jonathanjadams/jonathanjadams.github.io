##########################################################################################
#
# make_var_fns.R
#
# Code to define the functions that make the VARs for the "Inflation Sentiments" project
# Philip Barrett, Washington DC
# First version: 25jan2022
#
##########################################################################################

library(tidyverse)
library(vars)
library(expm)   
library(nleqslv)
library(lubridate)
library(magrittr)
select <- dplyr::select
# Otherwise picks up the MASS usage

make.var <- function( df, value.name, var.name, fcast, inf, y, lags=NA, lag.max=24, lag.select='AIC', m.Y=NA ){
  # Makes a VAR and returns the reduced form coefficients.  Lags can be AIC, HQ, SC, or FPE
  
  if( is.na(m.Y)){
    m.Y <- df %>%
      filter( !!as.symbol(var.name) %in% c( fcast, inf, y ) ) %>%
      select(date, !!var.name, !!value.name) %>%
      spread( variable, !!value.name ) %>%
      select( fcast, inf, y ) %>%
      as.matrix
      # The matrix of data for the VAR
  }
  n.vars <- ncol(m.Y)
    # The number of variables
  y.means <- m.Y %>% colMeans()
    # Should be v close to zero if de-seasonalizing correctly
  
  if( lags %>% is.na ){
    lagselect <- VARselect( m.Y, lag.max=lag.max )
    lags <- lagselect$selection[paste0(lag.select, '(n)')]
  }
    # Select the lag structure if required
  
  p <- lags
    # Because using the name "lags" causes errors later.  Weird.
  var.est <- VAR( m.Y, p, type='none', season=NULL, exog=NULL )
    # The estimated reduced-form VAR
  m.B.1 <- var.est$varresult %>% sapply( ., coef) %>% t
    # The matrix of VAR coefficients
  if( p==1 ){
    m.B <- m.B.1
  }else{
    lagmat <- cbind( diag(n.vars*(p-1)), matrix( 0, n.vars*(p-1), n.vars ) )
    rownames(lagmat) <- colnames(m.B.1)[1:(n.vars*(p-1))]
    m.B <- rbind( m.B.1, lagmat )
  }
  # m.Sigma <- var.est %>% summary %>% .$covres
  m.Sigma <- var.est %>% resid() %>% var()
    # The reisidual variance-covariance matrix
  
  return( list( B=m.B, Sigma=m.Sigma, n.vars=n.vars, lags=p, mu=y.means, data=m.Y, var=var.est ) )
}

make.phi.h <- function( l.var, horiz=12, inf.idx=2 ){
# Makes the cummulative response for inflation at horizon h.  Assumes ordering
# of shocks is (fcast, inf, others)
  
  n.vars <- l.var$n.vars
    # Number of variables
  phi.k <- lapply( 1:horiz, function(x) l.var$B %^% x ) %>%
    Reduce( '+', . )
    # The cummulative IRFs for all variables
  out <- phi.k[inf.idx,1:n.vars] ; names(out) <- rownames(phi.k)[1:n.vars]
  return( out )
    # Select the inflation response
}

make.var.fcast <- function( m.B, m.Y, n.fcast.pds=1 ){
# Makes a forecast of the VAR, n.pds ahead
  n.vars <- m.Y %>% ncol()
  n.pds <- m.Y %>% nrow()
  n.lags <- (m.B %>% ncol) / n.vars
    # Problem dimensions
  m.fcast <- (( m.B %^% n.fcast.pds ) %>% t()) %>% .[,1:n.vars]
    # The multi-period forecast matrix
  m.out <- matrix( NA, n.pds, n.vars ) %>% set_colnames( colnames(m.Y) )
    # The output matrix
  m.Y.use <- matrix(NA, n.pds, n.vars*n.lags ) %>% set_colnames( rownames(m.B) )
  for( j in 1:n.lags ) m.Y.use[j:n.pds,(j-1)*n.vars+1:n.vars] <- m.Y[1:(n.pds+1-j),]
    # Fill out the data to use as a matrix
  for( i in n.lags:n.pds ){
    m.out[i,] <- m.Y.use[i,] %*% m.fcast
  }
  return(m.out)
}

anc.T <- function( anc, big.sigma, phi.h, return.A=FALSE ){
# The operator T, mapping from a guess of anc to a new one
  
  nn <- dim( big.sigma )[2]
    # Number of variables
  if( length(anc) != nn-1) stop('length(anc.guess) must match number of non-forecast variables' )
    # Check the dimensions are ok
  
  afc.target <- big.sigma[ 2:nn, 2:nn ] - anc %*% t(anc)
    # Something we want to do a cholesky decomp on, but it might not be PD
  target.ev <- eigen( afc.target )
    # Do an eigenvector decomp of the target
  afc.target.pd <- target.ev$vectors %*% diag( pmax( 1e-08, target.ev$values ) ) %*% t( target.ev$vectors )
    # The positive-definite version of the target (returns the original target if already PD)
  if(min(target.ev$values)<0){
    # browser()
    warning('The cholesky sub-matrix is not positive definite. Check sigma.err')
  }
    # Warning message
  afc <- chol( afc.target.pd ) %>% t
    # Compute the lower RHS
  
  phi.h.fcast <- phi.h[1]
  phi.h.c <- phi.h[-1]
  aff <- 1 / ( 1 - phi.h.fcast ) * ( t(phi.h.c) %*% afc )
    # The upper RHS
  
  anf <- sqrt( max( 1e-08, big.sigma[1,1] - sum(aff^2) ) )
    # The upper LHS: Add a small error to prevent faliure of the inversion
  
  anc.new <- ( big.sigma[-1,1] - afc %*% t(aff) ) / anf
    # The update for anc
  
  if(return.A){
    out <- cbind( c( anf, anc.new ),
                  rbind( aff, afc ) )
    rownames(out) <- rownames(big.sigma)
    colnames(out) <- NULL
    return(out)
  }else{
    return(anc.new)
  }
  
}

anc.iter <- function(  big.sigma, phi.h, anc=NA,tol=1e-08, maxit=100, gain=.5, verbose=FALSE ){
# Iteratres the operator T to find the fixed point solution
  
  if(is.na(anc)) anc <- rep(0,dim(big.sigma)[2]-1)
    # Set the initial guess if required
  
  anc.0 <- anc
  iter <- 0 ; err <- 2*tol
  while( iter < maxit & err > tol ){
    new.anc <- gain * ( anc.T( anc, big.sigma, phi.h ) ) + (1-gain) * anc
    err <- ((anc - new.anc) %>% abs %>% max) / gain
    anc <- new.anc
    iter <- iter + 1
    
    if(verbose & (iter %% 10 == 0) ){
      message('Iteration ', iter, ' err = ', round(err,4) )
    }
  }
  
  A <- anc.T( anc, big.sigma, phi.h, return.A=TRUE )
    # The output
  # browser()
  sigma.err <- max( abs( big.sigma - (A %*% t(A)) ) )
    # The gold standard check on iteration -- may fail if the PD constraint binds :(
  status <- if(max(err, sigma.err / 10 ) < tol) 'success' else 'failure'
  return( list( A=A, anc=anc, anc.0=anc.0, err=err, sigma.err=sigma.err, status=status, iter=iter ) )
  
}

anc.T.err <- function( anc, big.sigma, phi.h ){
  return( anc - anc.T( anc, big.sigma, phi.h ) )
}

anc.nlslv <- function( big.sigma, phi.h, anc=NA, tol=1e-08 ){
# Solves for the structural form decomposition
  
  if(is.na(anc)) anc <- rep(0,dim(big.sigma)[2]-1)
  # Set the initial guess if required
  
  anc.0 <- anc
  this.anc.err <- function(anc) anc.T.err( anc, big.sigma, phi.h )
    # Make the local function to solve
  sol <- nleqslv( anc.0, this.anc.err, control=list(maxit=10000) )
    # Solve the nonlinear equations
  anc <- sol$x
    # The correct anc
  A <- anc.T( anc, big.sigma, phi.h, return.A=TRUE )
    # The output
  err <- sol$fvec %>% abs %>% max
    # The solution error
  sigma.err <- max( abs( big.sigma - (A %*% t(A)) ) )
    # The gold standard check
  status <- if(max( err, sigma.err / 10 ) < tol) 'success' else 'failure'

    return( list( A=A, anc=anc, anc.0=anc.0, err=err, sigma.err=sigma.err, status=status ) )
}

var.decomp <- function( A, l.var, n.pds=20 ){
# The variance decomposition
  
  l.var.decomp.ratio <- l.var.decomp <- list()
  n.vars <- l.var$n.vars
    # Number of variables
  p <- l.var$lags
    # The number of lags
  big.sigma <- l.var$Sigma
  B <- l.var$B
    # Extract the VAR elements
  
  A.sq.extended <- lapply( 1:n.vars, function(x){ 
    out <- 0*diag( n.vars * p )
    out[1:n.vars,1:n.vars] <- A[,x] %*% t(A[,x])
    return(out)
  } )
  big.sigma.extended <- 0*diag( n.vars * p ) ; big.sigma.extended[1:n.vars,1:n.vars] <- big.sigma
    # The lag-extended var-covar matrices
  big.sigma.denominator <- 0
    # Useful for the variance ratio
  
  for( i in 1:n.pds ){
    if( i==1 ){
      l.var.decomp[[i]] <- lapply( 1:n.vars, function(x) ((B %^% i) %*% A.sq.extended[[x]] %*% t(B %^% i))[1:n.vars,1:n.vars] )
    }else{
      l.var.decomp[[i]] <- lapply( 1:n.vars, function(x) l.var.decomp[[i-1]][[x]] + 
                                     ((B %^% i) %*% A.sq.extended[[x]] %*% t(B %^% i))[1:n.vars,1:n.vars] )
    }
    big.sigma.denominator <- big.sigma.denominator + ((B %^% i) %*% big.sigma.extended %*% t(B %^% i))[1:n.vars,1:n.vars]
    l.var.decomp.ratio[[i]] <- sapply( 1:n.vars, function(x) diag(l.var.decomp[[i]][[x]]) / 
                                       diag( big.sigma.denominator) )
    
    colnames(l.var.decomp.ratio[[i]]) <- c( 'Non-fundamental', paste0( 'Fundamental #', 1:(n.vars-1) ))
  }
  
  return( list( var.decomp=l.var.decomp, decomp.ratio=l.var.decomp.ratio ) )
  
}

anc.nlslv.robust <- function( big.sigma, phi.h, outer.iter=20, anc=NA, tol=1e-08  ){
  # Solves for the structural form decomposition
  
  
  first.sol <- anc.nlslv( l.var.coefs$Sigma, est.phi.h, anc, tol )
  if( first.sol$status == 'success' ) return(first.sol)
  
  this.status <- 'failure'
  iter <- 0 ; this.sd <- .01
  n.anc <- first.sol$anc %>% length()
  while( this.status =='failure' & iter < outer.iter){
    this.anc <- rnorm(n.anc, 0, this.sd)
    this.sol <- anc.nlslv( l.var.coefs$Sigma, est.phi.h, this.anc, tol )
    this.sd <- this.sd + .09 / outer.iter
    this.status <- this.sol$status
    iter <- iter + 1
  }
  
  return( this.sol )
}




