##########################################################################################
#
# master.R
#
# Master code to calculate the results in "Inflation Sentiments"
# Philip Barrett, Washington DC
# First version: 25jan2022
#
##########################################################################################

##########################
# TO DOs
#  - Split charts out as a separate thing [2]


#### 0. Set up global options ####

## 0.1 Housekeeping ##
rm(list=ls())
library(tidyverse)
setwd('C:\\Users\\pbarrett\\OneDrive - International Monetary Fund (PRD)\\inflation_sentiments')
xl.in.dta <- 'data/Baseline Time Series/inflation_sentiments'

## 0.1 Controls ##
make.data <- TRUE # FALSE # 
l.cases <- list( 
  list(freq='m', fcast='michigan.fcast', inf='inf.cpi', y=c( 'fed.funds.rate', 'unemp', 'log.ip', 'inf.commod'), init.yr=NA, robust=FALSE) #,
  # list(freq='m', fcast='cleveland.fcast', inf='inf.cpi', y=c( 'fed.funds.rate', 'unemp', 'log.ip', 'inf.commod'), init.yr=NA, robust=FALSE),
  # list(freq='q', fcast='fed.fcast', inf='inf.gdp', y=c('fed.funds.rate', 'log.gdp', 'log.inv', 'log.cons'), init.yr=1982, robust=FALSE),
  # ## # Both monthly series start in 1982
  # ## list(freq='q', fcast='spf.fcast', inf='inf.gdp', y=c('fed.funds.rate', 'log.gdp', 'log.inv', 'log.cons'), init.yr=NA, robust=FALSE),
  # ## # The earlier version is not numerically stable
  # list(freq='q', fcast='spf.fcast', inf='inf.gdp', y=c('fed.funds.rate', 'log.gdp', 'log.inv', 'log.cons'), init.yr=1982, robust=FALSE) #,
  # list(freq='q', fcast='spf.fcast', inf='inf.gdp', y=c('fed.funds.rate', 'log.gdp', 'log.inv', 'log.cons'), init.yr=1990, final.yr=2010, robust=FALSE)
  )

n.cases <- l.cases %>% length()
  # The number of cases 


########## MAIN Computational loop
for(i.case in 1:n.cases ){  # ){ #
  
  #### 1. Set up ####
  
  ## 1.1 Extract controls
  freq <- l.cases[[i.case]]$freq
  fcast <- l.cases[[i.case]]$fcast
  init.yr <- l.cases[[i.case]]$init.yr
  final.yr <- if( is.null(l.cases[[i.case]]$final.yr) ) NA else l.cases[[i.case]]$final.yr
  inf <- l.cases[[i.case]]$inf
  y <- l.cases[[i.case]]$y
  robust <- l.cases[[i.case]]$robust
  irf.pds <- if(freq=='m') 36 else 12
  irf.plot.pds <- irf.pds - if(freq=='m') 12 else 4
  
  robust <- FALSE
    ### TEMPORARY LINE BECUASE ROBUSTNESS CHECKS TAKE AGES
  
  ## 1.2 Monitoring ##
  message( '\n\n******** CASE # ', i.case, ' ********')
  message( 'Inflation forecast series = ', fcast, ', Initial year = ', init.yr, '\n\n' )
  
  ## 1.4 Define functions ####
  source('code/R/make_var_fns.R')
  source('code/R/make_irf_fns.R')
  source('code/R/make_lp_fns.R')
  
  #### 2. Read and process the data ####
  if( make.data){
    source('code/R/make_clean_data_US.R')
  }else{
    load('data/baseline_time_series.rdta')  
  }
  df <- if(freq=='m') df.m else df.q
  init.yr <- if(is.na(init.yr)) df$date %>% min %>% year else init.yr
  final.yr <- if(is.na(final.yr)) df$date %>% max %>% year else final.yr
  df <- df %>% filter( year( date ) >= init.yr, year( date ) <= final.yr ) 
  
  #### 3. Estimate the reduced forms ####
  l.var.coefs <- make.var( df, value.name='value.deseas', var.name='variable', fcast=fcast, inf=inf, y=y, lag.max=8 ) #, lags = 2 )
  
  #### 4. Compute the structural decomposition ####
  fcast.horiz <- if(freq=='m') 12 else 4
  est.phi.h <- make.phi.h( l.var.coefs, horiz = fcast.horiz )
  est.A <- anc.nlslv.robust( l.var.coefs$Sigma, est.phi.h )
  # est.A.iter <- anc.iter( l.var.coefs$Sigma, est.phi.h )
  est.var.decomp <- var.decomp( est.A$A, l.var.coefs, n.pds = irf.pds )
  
  #### 5. Make the IRFs ####
  # Bootstrap the residuals 
  est.bootstrap <- make.bootstrap( l.var.coefs, est.A$A, fcast.horiz=fcast.horiz, 
                                   inf.name=inf, n.pds = irf.pds )
  est.lp <- make.lp.irf( df, est.A, l.var.coefs, inf.name=inf, 
                         this.fcast=fcast, irf.pds=irf.pds )

  #### 5.a Do the robustness checks ####
  if(robust){
    source('code/R/robust_selection.R')
    # source('code/R/robust_roll.R')
  } 
  # if(robust) source('code/R/robust_roll.R')
  
  #### 6. Make some charts ####
  source('code/R/charts.R')
  
  
  #### 7. Run some checks ####
  source('code/R/checks.R')

}

stop()

#### 8. The final chart putting the IRFs all together ####
source('code/R/comparison_charts.R')




