##########################################################################################
#
# comparison_charts.R
#
# Code to make charts comparing the IRFs in the  "Inflation Sentiments" project
# Philip Barrett, Washington DC
# First version: 13feb2022
#
##########################################################################################

#### 0. Set up ####
rm(list=ls())
setwd('C:\\Users\\pbarrett\\OneDrive - International Monetary Fund (PRD)\\inflation_sentiments')
library(tidyverse)
library(ggplot2)
library(zoo)
library(xtable)
select <- dplyr::select
  # Otherwise picks up the MASS usage 

#### 1. Controls ####
v.irfs <- paste0( 'data/', c( 'michigan_1982_m_3', 'cleveland_1982_m_3', 'spf_1982_q_2', 'fed_1982_q_2'  ), '.rdata')
  # The locations of the data
l.compare <- list( 
  c( fcast='michigan.fcast', inf='inf.cpi', act='log.ip', fed.funds.rate='fed.funds.rate' ),
  c( fcast='cleveland.fcast', inf='inf.cpi',  act='log.ip', fed.funds.rate='fed.funds.rate' ),
  c( fcast='spf.fcast', inf='inf.gdp', act='log.gdp', fed.funds.rate='fed.funds.rate' ),
  c( fcast='fed.fcast', inf='inf.gdp', act='log.gdp', fed.funds.rate='fed.funds.rate' ) )
  # The details for comparing the different types of estimation
v.freq <- c( ' Michigan'='m', Cleveland='m', SPF='q', 'Fed Greenbook'='q' )
  # The frequency
var.labs <- c( fcast='One-year-ahead inflation expectations, percent', 
               inf.a='Realized inflation, current month',
               act='100 * Log activity', 
               fed.funds.rate='Federal Funds Rate, percent', 
               inf.fire='Realized inflation, one year ahead', 
               inf.sentiment='Inflation sentiment' )
  # The variable labels
var.labs.tab <- c( fcast='Year-ahead inf. exp.', inf='Realized inflation',
               act='100 * Log activity', fed.funds.rate='Federal Funds Rate' )
  # The variable labels for the table
n.compare <- l.compare %>% length()


#### 2. Assemble the data ####

l.sent.ar <- list()
df.var.decomp.all <- NULL

for( i.compare in 1:n.compare ){
  
  load( v.irfs[i.compare] )
    # Load the file
  freq <- v.freq[i.compare]
  inf.ann <- if(freq=='m') function(x) x*12 else function(x) x*4
  # inf.ann <- if(freq=='m') function(x) rollsum( c( rep(0,11), x ), 12, align='l' ) else function(x) rollsum( c( rep(0,3), x ), 4, align='l' )
  #   # Alternative specification: show annual inflation rate response
  pd.mth <- if(freq=='m') identity else function(x) x*3+1
    # Functions to adjust inflation to be annualized and periods to be monthly only
  this.df.nf.chart <- df.irf.struct %>% 
    filter(shock=='Non-fundamental') %>% 
    select(-outcome) %>% 
    spread(outcome.f,value) %>% 
    rename(l.compare[[i.compare]]) %>% 
    mutate( period.m=pd.mth(period), inf.a=inf.ann(inf) ) %>%
    select( period.m, fcast, inf.a, act, fed.funds.rate, inf.fire, inf.sentiment ) %>%
    gather( outcome, value, -period.m ) %>%
    mutate( type=names(v.freq)[i.compare],
            outcome=fct_relevel( outcome, c('fcast', 'inf.fire', 'inf.sentiment', 'inf.a', 'fed.funds.rate', 'act') ) )
  df.nf.chart <- if(i.compare==1) this.df.nf.chart else full_join( df.nf.chart, this.df.nf.chart )
  
  l.sent.ar[[names(v.freq)[i.compare]]] <- this.df.nf.chart %>% filter( outcome == 'inf.sentiment', !is.na(value), value >=.01 ) %>% 
    pull(value) %>% ar(order.max=1, aic=FALSE)
  
  this.var.decomp <- 
    # full_join( 
      est.bootstrap$var.decomp %>% 
               filter( horizon==max(horizon), shock!='Fundamental') %>% 
               select(outcome, horizon, q.05, q.95, pt.est=q.50) %>% #,
               # df.var.decomp %>% filter( horizon==max(horizon), shock!='Fundamental') %>%
               # select( outcome, horizon, pt.est=value )
               # ) 
    filter( outcome %in% l.compare[[i.compare]] ) %>%
    mutate( type=names(v.freq)[i.compare],
            outcome.tab=names(l.compare[[i.compare]])[match( outcome, l.compare[[i.compare]])],
            outcome.name=var.labs.tab[outcome.tab] ) %>%
    select(type, outcome.name, everything() )
  df.var.decomp.all <- if( i.compare > 1 ) full_join(df.var.decomp.all, this.var.decomp) else this.var.decomp
  
}

load('data/baseline_time_series.rdta')  

df.all.fcast <- df.m %>% filter( variable %in% c('michigan.fcast', 'cleveland.fcast')) %>%
  full_join( ., df.q %>% filter( variable %in% c('spf.fcast', 'fed.fcast') ) ) %>%
  mutate( plt.var=case_when( variable=='michigan.fcast'~' Michigan',
                             variable=='cleveland.fcast'~'Cleveland Fed',
                             variable=='spf.fcast'~'SPF',
                             variable=='fed.fcast'~'Fed Greenbook' ) ) %>%
  ungroup() %>%
  select(date, plt.var, value, value.deseas ) %>%
  gather( type, value, -date, -plt.var )
gg.fcast.compare <- ggplot( df.all.fcast, 
                            aes(x=date, y=value, color=plt.var, type=plt.var, shape=plt.var) ) +
  geom_line(lwd=.9) +
  # geom_point(size=3) +
  facet_wrap(~type, label=labeller( type=c( value='Raw data', value.deseas='Deseasonalized and detrended') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  geom_hline(yintercept=0, lwd=.5) +
  labs( color='Measure') +
  xlab('Date')
gg.fcast.compare %>% print()
ggsave(gg.fcast.compare, filename = 'graphs/fcast_compare.pdf', height=6, width=10 )

v.sent.ar <- l.sent.ar %>% sapply( ., function(x) x$ar )
  # The sentiment persistences

gg.compare <- 
ggplot(df.nf.chart, aes( x=period.m, y=value, group=type, color=type, shape=type)) +
  geom_line(lwd=.9) +
  geom_point(size=3) +
  facet_wrap(~outcome, label=labeller( outcome=var.labs ) ) +
  theme_minimal() + 
  theme(legend.position = 'bottom') +
  labs( color='Measure', lty='Measure', shape='Measure' ) +
  xlab('Months') + ylab('') +
  geom_hline(yintercept=0) +
  # xlim(c(0,24)) +
  scale_x_continuous( breaks=seq(0,24,6), limits = c(0,24) )
gg.compare %>% print()
ggsave(gg.compare, filename = 'graphs/irf_compare.pdf', height=6, width=10 )

df.var.decomp.tab <- df.var.decomp.all %>%
  ungroup() %>%
  mutate( range = paste0( '(', formatC(q.05, 2, format = 'f'), ', ', 
                          formatC(q.95, 2, format='f'), ')' ),
          pt.est=formatC(pt.est,2,format='f')) %>% 
  select(type, outcome.name, pt.est, range ) %>%
  gather( key, value, -type, -outcome.name ) %>%
  spread( type, value ) %>%
  select(-key) %>%
  mutate( outcome.name=ifelse( outcome.name==c(outcome.name[-1],' '), outcome.name, '')) %>%
  select( everything(), -'Fed Greenbook', 'Fed Greenbook') %>%
  rename( ' '=outcome.name)

table.string <- 'Long-run share of variance, sentiment shock. 
          Bootstrapped 90 percent confidence interval in parentheses.'
print( xtable( df.var.decomp.tab, label='t:var_decomp',
               caption = table.string, align = c('l','l','c','c','c','c') ),
      include.rownames=FALSE, hline.after=c(-1,-1,0,8), floating = FALSE, file = 'tables/var_decomp.tex' ) #,
      # floating.environment = 'sidewaystable' )








