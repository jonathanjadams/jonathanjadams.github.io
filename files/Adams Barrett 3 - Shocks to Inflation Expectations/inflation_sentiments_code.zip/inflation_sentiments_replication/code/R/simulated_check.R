##########################################################################################
#
# simulated_check.R
#
# Code to check the identification of the shck using simulated data
# Philip Barrett, Washington DC
# First version: 02feb2022
#
##########################################################################################

#### 0. Set up ####
rm(list=ls())
setwd('C:\\Users\\pbarrett\\OneDrive - International Monetary Fund (PRD)\\inflation_sentiments')
source('code/R/make_var_fns.R')
source('code/R/make_irf_fns.R')
library(magrittr)
set.seed(42)

#### 1. Controls ####
max.est.lag <- 10
freq <- 12
  # The frequency of the eventual simulated data


#### 2. Warm-up I: The simple NK, zero-persistence case ####

## 2.1 Read in the data ####
m.Y <- read_csv('./data/simulated/simdata_NK3s.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix()
m.shocks <- read_csv('./data/simulated/simshocks_NK3s.csv', col_names =c('sentiment', 'tech', 'monetary')) %>% 
  as.matrix()
m.B <- read_csv('./data/simulated/Bmatrix_NK3s.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix() %>% set_rownames(c('fcast', 'inflation', 'output'))
m.A <- read_csv('./data/simulated/Amatrix_NK3s.csv', col_names =c('sentiment', 'tech', 'monetary') ) %>% 
  as.matrix() %>% set_rownames(c('fcast', 'inflation', 'output'))
m.Sigma <- read_csv('./data/simulated/Sigma_resid_NK3s.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix() %>% set_rownames((c('fcast', 'inflation', 'output')))
m.Sigma.A <- m.A %*% t(m.A)


## 2.2 Estimate the reduced form VAR ### 
l.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', 
                       y='output', m.Y=m.Y, lags = 1 )
B.err <- max(abs(l.var.sim$B - m.B))
Sigma.err <- max(abs(l.var.sim$Sigma - m.Sigma))

## 2.3 Check the structural form ##
sim.phi.h <- make.phi.h( l.var.sim )
A.sim <- anc.nlslv( l.var.sim$Sigma, sim.phi.h )
sent.err <- max(abs(m.A[,'sentiment'] - A.sim$A[,1]))


#### 3. Warm-up II: The simple NK, non-zero-persistence case ####

## 3.1 Read in the data ####
m.Y <- read_csv('./data/simulated/simdata_NK3sp.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix()
m.shocks <- read_csv('./data/simulated/simshocks_NK3sp.csv', col_names =c('sentiment', 'tech', 'monetary') ) %>% 
  as.matrix()
m.B <- read_csv('./data/simulated/Bmatrix_NK3sp.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix() %>% set_rownames(c('fcast', 'inflation', 'output'))
m.A <- read_csv('./data/simulated/Amatrix_NK3sp.csv', col_names = c('sentiment', 'tech', 'monetary') ) %>% 
  as.matrix() %>% set_rownames(c('fcast', 'inflation', 'output')) 
m.Sigma <- read_csv('./data/simulated/Sigma_resid_NK3sp.csv', col_names =c('fcast', 'inflation', 'output') ) %>% 
  as.matrix() %>% set_rownames((c('fcast', 'inflation', 'output')))
m.Sigma.A <- m.A %*% t(m.A)

## 3.2 Check the structural impact from the estimated impact using true shocks ##
l.A.est <- lapply( 0:max.est.lag, function(j) 
  sapply( 1:ncol(m.Y), function(i){
    Y <- if(j==0) m.Y[,i] else ( VAR( m.Y, p=j ) %>% resid %>% .[,i] )
      # Partial out the VAR lags
    X <- if( j==0 ) m.shocks else m.shocks[-(1:j),]
    lm( Y ~ X ) %>% coef %>% .[paste0('X', colnames(m.shocks))] 
    } ) %>% t() %>% set_colnames( colnames(.) %>% gsub('X', '', .) ) )

## 3.3 Estimate the reduced form VAR ### 
l.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', 
                       y='output', m.Y=m.Y, lags = 1 )
B.err <- max(abs(l.var.sim$B - m.B))
Sigma.err <- max(abs(l.var.sim$Sigma - m.Sigma))

## 3.5 Check the structural form ##
sim.phi.h <- make.phi.h( l.var.sim )
A.sim <- anc.nlslv( l.var.sim$Sigma, sim.phi.h )
sent.err <- max(abs(m.A[,'sentiment'] - A.sim$A[,1]))
