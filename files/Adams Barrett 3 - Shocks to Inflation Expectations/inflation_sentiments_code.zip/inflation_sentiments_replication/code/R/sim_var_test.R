##########################################################################################
#
# sim_var_test.R
#
# Code to simulate and check VAR estimation for the "Inflation Sentiments" project
# Philip Barrett, Washington DC
# First version: 03feb2022
#
##########################################################################################

#### 0. Set up ####
rm(list=ls())
setwd('C:\\Users\\pbarrett\\OneDrive - International Monetary Fund (PRD)\\inflation_sentiments')
library(vars)
library(tsDyn)

#### 1. Define functions ####
source('code/R/make_var_fns.R')
source('code/R/make_irf_fns.R')


#### 2. Simulate the VAR and back out the estimated coefficients ####
A.sim <- matrix( c( 1, 0, 0, .5, 1.2, 0, .3, .2, .8 ), 3, 3, byrow = TRUE )
B.sim <- matrix( c( .5, .2, -.1, -.2, .4, .1, .3, .2, .2), 3, 3, byrow = TRUE )
Sigma.sim <- A.sim %*% t(A.sim)
m.Y <- VAR.sim( B.sim, n=10000, include='none', varcov=Sigma.sim )
l.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', y='output', m.Y=m.Y, lags = 1 )
B.err <- max(abs(l.var.sim$B - B.sim))
Sigma.err <- max(abs(l.var.sim$Sigma - Sigma.sim))
A.err <- max(abs(chol(l.var.sim$Sigma) %>% t - A.sim))
  # These all look nice and small