##########################################################################################
#
# simulated_check_full.R
#
# Code to check the identification of the shock using simulated data from a full NK model
# Philip Barrett, Washington DC
# First version: 24feb2022
#
##########################################################################################

#### 0. Set up ####
rm(list=ls())
setwd('C:\\Users\\pbarrett\\OneDrive - International Monetary Fund (PRD)\\inflation_sentiments')
source('code/R/make_var_fns.R')
source('code/R/make_irf_fns.R')
library(magrittr)
set.seed(42)

#### 1. Controls ####
freq <- 'm'
  # The frequency of the eventual simulated data
max.est.lag <- if(freq=='m') 10 else 6
ann.pds <- if(freq=='m') 12 else 4


#### 2. Read in the data ####
m.Y <- read_csv('./data/simulated/simdata.csv', col_names =c('fcast', 'inflation', 'output', 'fed.funds') ) %>% 
  as.matrix()
m.shocks.in <- read_csv('./data/simulated/simshocks.csv', col_names =c('sentiment', 'tech', 'monetary', 'preferences', 'news') ) %>% 
  as.matrix()
m.shocks <- m.shocks.in / ( ( m.shocks.in %>% nrow %>% rep(1, .) ) %*% (m.shocks.in %>% var %>% diag() %>% sqrt %>% t) )
df.irf.dynare <- read_csv( './data/simulated/simirfs.csv', col_names =c('fcast', 'inflation', 'output', 'fed.funds', 'inf.sentiment.1pd') )
# df.irf.dynare <- df.irf.dynare.in %>% mutate_all( function(x) x/ df.irf.dynare.in$sentiment[1] )

#### 3. Point estimates of the IRFs ####

## 3.1 The true(ish) structural impact from regressing on the actual shocks with multiple lag lengths ##
l.A.est <- lapply( 0:max.est.lag, function(j) 
  sapply( 1:ncol(m.Y), function(i){
    Y <- if(j==0) m.Y[,i] else ( VAR( m.Y, p=j ) %>% resid %>% .[,i] )
      ##### CHECK HERE THAT THERE IS NO CONSTANT.  AND ALSO BELOW. #####
    # Partial out the VAR lags
    X <- if( j==0 ) m.shocks else m.shocks[-(1:j),]
    lm( Y ~ X ) %>% coef %>% .[paste0('X', colnames(m.shocks))] 
  } ) %>% t() %>% set_colnames( colnames(.) %>% gsub('X', '', .) ) )

## 3.2 Estimate the reduced form from the simulated data ##
l.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', 
                       y=c( 'output', 'fed.funds' ), m.Y=m.Y, lag.max = max.est.lag )
i.lag.idx <- l.var.sim$lags + 1
  # Adding one because the first entry is zero lags

## 3.3 Select the true structural decomp from the appropriate VAR by lag length ##
m.A.est <- l.A.est[[i.lag.idx]]
  # Select the correct structural impact matrix
anc.0 <- m.A.est[-1,1] # * rnorm( ncol(m.Y)-1, 1, .05)
  # Set anc.0~=anc but with a small perturbation to simulate incorrect init conds

## 3.4 Estimate the structural decomp using the true solution as an IC ##
sim.phi.h <- make.phi.h( l.var.sim, horiz = ann.pds )
A.sim <- anc.nlslv( l.var.sim$Sigma, sim.phi.h, anc=anc.0 )

## 3.5 Check against the estimated parts of the VAR (etc.) ##
m.Sigma.est <- m.A.est %*% (m.shocks %>% var) %*% t(m.A.est)
  # The reduced form variance-covariance matrix
Sigma.err <- ( l.var.sim$Sigma - m.Sigma.est ) %>% abs %>% max
  # The error on the reduced form 
sent.err <- max(abs(m.A.est[,'sentiment'] - A.sim$A[,1]))
  # The sentimental error
if(A.sim$status=='success'){
  message('Full-sample structural decomposition succeeded')
}else{
  stop('Full-sample structural decomposition failed')
}

## 3.6 Plot the corresponding IRFs ##
m.A.est.square <- m.A.est[, 1:nrow(m.A.est)]
  # The square version of A. Need to drop the final shock as IRF code can only
  # handle n(shocks) = n(var).  Could also combine?
df.irf.struct.true <- make.irf.struct( l.var=l.var.sim, A=m.A.est.square, fcast.horiz=ann.pds, 
                                       inf.name='inflation', n.pds=3*ann.pds, fcast='fcast' )
df.irf.struct.sim <- make.irf.struct( l.var=l.var.sim, A=A.sim$A, fcast.horiz=ann.pds, 
                                      inf.name='inflation', n.pds=3*ann.pds, fcast='fcast' )
df.nf.struct <- full_join( df.irf.struct.true %>% filter(shock=='Non-fundamental') %>% mutate(Type=' Model'),
                           df.irf.struct.sim %>% filter(shock=='Non-fundamental') %>% 
                             mutate(Type='Long simulated sample') ) %>%
  select(-shock)
  # The IRFs
gg.validation <- ggplot( df.nf.struct, # %>% filter( !(outcome %in% c('inf.sentiment', 'inf.fire')) ), 
                         aes( x=period, y=value, group=Type, lty=Type ) ) +
  geom_hline(yintercept=0) +
  geom_line(lwd=1.1) +
  facet_wrap(~outcome, label=labeller( outcome=c( fcast='Inflation forecast', fed.funds='Interest Rate',
                                                  inf.sentiment='Inflation Sentiment', inf.fire='RE forecast',
                                                  inflation='Inflation', output='Log output') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  xlim(c(0,2*ann.pds)) +
  xlab('Periods') + ylab('Percentage points')
gg.validation %>% print
ggsave( paste0( 'graphs/validation_', freq, '.pdf'), gg.validation, height=8, width=8 )

## 3.7 Add in the true IRFs from the save files ##
df.nf.struct.full <- full_join( df.nf.struct,
                                df.irf.dynare %>% mutate(inf.sentiment=inf.sentiment.1pd %>%
                                                           rollsum(k=ann.pds, align = 'l', fill = NA),
                                                         Type='Dynare', period=1:nrow(.)-1 ) %>%
                                  gather(outcome, value, -period, -Type) )
gg.validation.full <- ggplot( df.nf.struct.full, aes( x=period, y=value, group=Type, color=Type ) ) +
  geom_hline(yintercept=0) +
  geom_line(lwd=1.1) +
  facet_wrap(~outcome, label=labeller( outcome=c( fcast='Inflation forecast', fed.funds='Interest Rate',
                                                  inf.sentiment='Inflation Sentiment', inf.fire='RE forecast',
                                                  inflation='Inflation', output='Log output', 
                                                  inf.sentiment.1pd='One-period inflation sentiment') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  xlim(c(0,2*ann.pds)) +
  xlab('Periods') + ylab('Percentage points')
gg.validation.full %>% print

## 3.8 Final check on the differences ##
df.check <- df.nf.struct.full %>% 
  full_join( {.} %>% group_by(Type ) %>% filter(outcome=='inflation') %>% 
               mutate(outcome='inf.fire.check', 
                      value=c(rollsum(value, 12, align='l', fill=NA)[-1],NA) ) ) %>% 
  spread( outcome, value ) %>%
  arrange(Type, period) %>%
  select( Type, period, inflation, inf.fire, inf.fire.check) %>%
  mutate(check.err=inf.fire-inf.fire.check)
df.check %>% filter( period <= ann.pds )  %>% print()
  # Ok these look good.


#### 4. Now do on repeated shorter samples ####
init.yr <- 1982 ; final.yr <- 2022
n.pds.sample <- ( final.yr - init.yr ) * ann.pds
  # The number of periods to sample
n.samples.poss <- nrow(m.Y) / n.pds.sample %>% floor
  # The number of samples available in total
n.sample <- 500
  # The number of samples to take
sample.starts <- (1:n.sample * ( nrow(m.Y) - 2 * n.pds.sample ) / n.sample) %>% floor
  # The initial start points for the samples
n.samples.anc.0 <- 2
  # The number of samples to extend by to get a good starting guess for anc

l.irf.nf <- list() ; i.counter <- 1 ; anc.0 <- m.A.est[-1,1] 
for( i in 1:n.sample ){
  
  message( 'Sample ', i )
  
  ## SET UP THE SAMPLE
  this.sample <- m.Y[ sample.starts[i] + 1:n.pds.sample, ]
  # The actual sample to estimate from
  this.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', 
                            y=c( 'output', 'fed.funds' ), m.Y=this.sample, lag.max = max.est.lag )
  this.sim.phi.h <- make.phi.h( this.var.sim, horiz = ann.pds )
  # The RF and targets
  
  ## QUICK TRY: USE THE SOLUTION FROM THE PREVIOUS ITERATION
  if( i==1 ) prev.anc <- anc.0
  # Set up the "previous" iteration  
  message( '  First trial' )
  this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=prev.anc )
  # Try solving with the anc.0 from the previous sample
  if( this.A.sim$status=='failure' ) message('  Failed, trying perturbation') else message('  Success!') 
  temp.it <- 0
  while( this.A.sim$status=='failure' & temp.it < 100 ){
    this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=prev.anc * rnorm( length(anc.0), 1, .1 ) )
    # Try perturbing if this fails
    temp.it <- temp.it + 1
  }
  if( this.A.sim$status=='failure' ) message('  Failed, trying longer sample IC') else if(  this.A.sim$status=='success' & temp.it>0) message('  Success!') 
  
  ## IF THIS FAILS, TRY SOLVING FOR A LARGER SAMPLE
  if(this.A.sim$status == 'failure'){
    
    init.sample <- m.Y[ max(1, sample.starts[ max( 1, i-n.samples.anc.0 ) ] 
    ):min(nrow(m.Y), sample.starts[ min( length(sample.starts), i+n.samples.anc.0 ) ] ), ]
    # Make a slightly larger sample for a good starting guess of anc.0
    init.var.sim <- make.var( NA, NA, NA, fcast='fcast', inf='inflation', 
                              y=c( 'output', 'fed.funds' ), m.Y=init.sample, lag.max = 5 )
    init.sim.phi.h <- make.phi.h( init.var.sim, horiz = ann.pds )
    init.A.sim <- anc.nlslv( init.var.sim$Sigma, init.sim.phi.h, anc=prev.anc )
    # Make an initial trial of the anc
    if( init.A.sim$status=='failure' ) message('  Failed, perturbing longer sample IC') else message('  Success, proceeding to try short sample again!') 
    
    temp.it <- 0
    while( init.A.sim$status=='failure' & temp.it < 100 ){
      init.A.sim <- anc.nlslv( init.var.sim$Sigma, init.sim.phi.h, anc=prev.anc * rnorm( length(anc.0), 1, .1 ) )
      # Try perturbing if this fails
      temp.it <- temp.it + 1
    }
    if( init.A.sim$status=='failure' ) message('  Failed')
    
    ## USING THE LARGER SAMPLE AS AN IC, TRY SOLVING THE SAMPLE
    if(init.A.sim$status == 'success'){
      this.anc.0 <- init.A.sim$anc    
      # Set the initial guess
      this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=this.anc.0 )
      # Structural responses
      temp.it <- 0
      if( this.A.sim$status=='failure' ) message('  Failed, trying perturbation') else message('  Success!') 
      while( this.A.sim$status=='failure' & temp.it < 100 ){
        this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=this.anc.0 * rnorm( length(anc.0), 1, .1 ) )
        # Try perturbing if this fails
        temp.it <- temp.it + 1
      }
      if( this.A.sim$status=='failure' ) message('  Failed, trying longer sample IC') else if(  this.A.sim$status=='success' & temp.it>0) message('  Success!')
    }
    
    # IF ALL ELSE FAILS, USE THE FULL-SAMPLE IC
    # if( init.A.sim$status != 'success' | ( init.A.sim$status == 'success' & this.A.sim$status=='failure') ){
    if( this.A.sim$status=='failure' ){
      message('  Attempting final estimation') 
      this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=anc.0 )
      # Structural responses
      if( this.A.sim$status=='failure' ) message('  Failed, trying perturbation') else message('  Success!') 
      while( this.A.sim$status=='failure' & temp.it < 100 ){
        this.A.sim <- anc.nlslv( this.var.sim$Sigma, this.sim.phi.h, anc=anc.0 * rnorm( length(anc.0), 1, .2 ) )
        # Try perturbing if this fails
        temp.it <- temp.it + 1
      }
      if( this.A.sim$status=='failure' ) message('  Failed') else message('  Success!') 
    }
  }
  
  
  if( this.A.sim$status == 'success' ){
    l.irf.nf[[i.counter]] <- suppressMessages( make.irf.struct( l.var=this.var.sim, A=this.A.sim$A, fcast.horiz=ann.pds, 
                                                                inf.name='inflation', n.pds=3*ann.pds, fcast='fcast' ) )
    i.counter <- i.counter+1
    prev.anc <- this.A.sim$anc
  }else{
    message( '** Dropping sample ', i , ' due to failure of structural decomp **')
  }
  
}

n.success <- l.irf.nf %>% length()
  # The number of successful samples

df.irf.nf.samples <- l.irf.nf %>% reduce( full_join ) %>%
  filter(shock=='Non-fundamental') %>%
  group_by( period, outcome ) %>% 
  summarise( q.005=quantile(value, .005, na.rm=T), q.025=quantile(value, .025, na.rm=T), 
             q.05=quantile(value, .05, na.rm=T), q.50=quantile(value, .50, na.rm=T),
             q.mean=mean(value, na.rm=T),
             q.95=quantile(value, .95, na.rm=T), q.975=quantile(value, .975, na.rm=T),
             q.995=quantile(value, .995, na.rm=T) )
  # Reassemble the samples
df.nf.struct.all <- df.irf.nf.samples %>% 
  rename( value=q.50 ) %>% 
  select( -contains('q.')) %>% 
  mutate( Type='Short sample median' ) %>%
  full_join( df.nf.struct ) %>%
  mutate(outcome.f = fct_relevel( outcome %>% as.factor, c('fcast', 'inf.fire', 'inf.sentiment', 'inflation', 'fed.funds', 'output' ) ))

save( df.irf.nf.samples, df.irf.nf.samples, df.nf.struct.all, file=paste0('data/sim_irf_', freq, '.rdata' ) )

gg.validation.range <- ggplot( df.nf.struct.all %>% 
                                 mutate(value=ifelse(outcome %in% c( 'fed.funds', 'inflation'), value * ann.pds, value ) ) ) +
  geom_ribbon( data = df.irf.nf.samples %>%
                 mutate(q.05=ifelse(outcome %in% c( 'fed.funds', 'inflation'), q.05 * ann.pds, q.05 ),
                        q.95=ifelse(outcome %in% c( 'fed.funds', 'inflation'), q.95 * ann.pds, q.95 ), 
                        outcome.f=as.factor(outcome) ), 
               aes(x=period, ymin=q.05, ymax=q.95 ), alpha=.1 ) +
  geom_hline(yintercept=0) +
  geom_line(lwd=.9, aes( x=period, y=value, group=Type, color=Type )) +
  geom_point(aes( x=period, y=value, group=Type, shape=Type, color=Type ), size=3) +
  facet_wrap(~outcome.f, scales='free_y',
             label=labeller( outcome.f=c( fcast='One-year-ahead inflation expectations, percent', 
                                          fed.funds='Interest Rate, percent annualized', 
                                          inf.fire='Realized inflation, one year ahead',
                                          inf.sentiment='Inflation sentiment',
                                          inflation='Realized inflation, current month', output='100 * Log output') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  xlim(c(0,2*ann.pds)) +
  xlab('Months') + ylab('') + labs( col=NULL, shape=NULL )
gg.validation.range %>% print
ggsave( paste0( 'graphs/validation_range_', freq, '.pdf'), gg.validation.range, height=8, width=10 )

## ADD THE ESTIMATED RESPONSES
load( 'data/michigan_1982_m_3.rdata' )

df.nf.chart.est <- df.irf.struct %>%
  filter(shock=='Non-fundamental') %>%
  select(-outcome) %>%
  spread(outcome.f,value) %>%
  rename(c( fcast='michigan.fcast', inf='inf.cpi', output='log.ip', fed.funds='fed.funds.rate' )) %>%
  mutate( inflation=inf * ann.pds ) %>%
  select( period, fcast, inflation, output, fed.funds, inf.fire, inf.sentiment ) %>%
  gather( outcome, value, -period ) %>%
  mutate(outcome.f = fct_relevel( outcome %>% as.factor, c('fcast', 'inf.fire', 'inf.sentiment', 'inflation', 'fed.funds', 'output' ) ))

shock.scalar <- df.nf.struct.all %>% filter(outcome=='inf.sentiment', period==0, Type==' Model') %>% pull(value) /
  df.nf.chart.est %>% filter(outcome=='inf.sentiment', period==0 ) %>% pull(value)

gg.validation.range.x <- ggplot( df.nf.struct.all %>% 
                                   mutate(value=ifelse(outcome %in% c( 'fed.funds', 'inflation'), value * ann.pds, value ) / shock.scalar ) ) +
  geom_ribbon( data = df.irf.nf.samples %>%
                 mutate(q.05=ifelse(outcome %in% c( 'fed.funds', 'inflation'), q.05 * ann.pds, q.05 ) / shock.scalar,
                        q.95=ifelse(outcome %in% c( 'fed.funds', 'inflation'), q.95 * ann.pds, q.95 ) / shock.scalar, 
                        outcome.f=as.factor(outcome) ) , 
               aes(x=period, ymin=q.05, ymax=q.95 ), alpha=.1 ) +
  geom_hline(yintercept=0) +
  geom_line(lwd=.9, aes( x=period, y=value, group=Type, color=Type )) +
  # geom_line( data=df.nf.chart.est, aes(x=period, y=value), lty=2, lwd=1.1 ) +
  geom_point(aes( x=period, y=value, group=Type, shape=Type, color=Type ), size=3) +
  facet_wrap(~outcome.f, scales='free_y',
             label=labeller( outcome.f=c( fcast='One-year-ahead inflation expectations, percent', 
                                          fed.funds='Interest Rate, percent annualized', 
                                          inf.fire='Realized inflation, one year ahead',
                                          inf.sentiment='Inflation sentiment',
                                          inflation='Realized inflation, current month',
                                          output='100 * Log output') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  scale_x_continuous( breaks=seq(0,2*ann.pds,ann.pds/2), limits = c(0,2*ann.pds) ) +
  xlab('Months') + ylab('') + labs( col=NULL, shape=NULL )
gg.validation.range.x %>% print
ggsave( paste0( 'graphs/validation_range_', freq, '_x.pdf'), gg.validation.range.x, height=6, width=10 )


df.irf.compare <- df.nf.struct.all %>% filter(Type==' Model') %>%
  mutate(value=ifelse(outcome %in% c( 'fed.funds', 'inflation'), value * ann.pds, value ) / shock.scalar ) %>%
  full_join( df.nf.chart.est %>% mutate(Type='Estimated impulse responses') )

gg.comparison <- ggplot( df.irf.compare ) +
  geom_hline(yintercept=0) +
  geom_line(lwd=.9, aes( x=period, y=value, group=Type, color=Type )) +
  geom_point(aes( x=period, y=value, group=Type, shape=Type, color=Type ), size=3) +
  facet_wrap(~outcome.f, scales='free_y',
             label=labeller( outcome.f=c( fcast='One-year-ahead inflation expectations, percent', 
                                          fed.funds='Interest Rate, percent annualized', 
                                          inf.fire='Realized inflation, one year ahead',
                                          inf.sentiment='Inflation sentiment',
                                          inflation='Realized inflation, current month', 
                                          output='100 * Log output') )) +
  theme_minimal() +
  theme(legend.position = 'bottom') +
  scale_x_continuous( breaks=seq(0,2*ann.pds,ann.pds/2), limits = c(0,2*ann.pds) ) +
  xlab('Months') + ylab('') + labs( col=NULL, shape=NULL )
gg.comparison %>% print
ggsave( paste0( 'graphs/comparison_', freq, '.pdf'), gg.comparison, height=6, width=10 )



