##########################################################################################
#
# charts.R
#
# Code to make charts for the "Inflation Sentiments" project
# Philip Barrett, Washington DC
# First version: 26jan2022
#
##########################################################################################

#### 1. Plot the time series ####
var.labs <- c( cleveland.fcast='Cleveland Inflation Forecast', michigan.fcast='Michigan Inflation Forecast',
               fed.fcast='Fed Green Book Forecast',
               fed.funds.rate='Federal Funds Rate', inf.commod='Commodity price inflation', 
               inf.cpi='CPI inflation', inf.pce='PCE growth', ip.gth='Industrial production growth',
               m2.gth='M2 Growth', unemp='Unemployment', fed.funds.diff='Change in Fed Funds rate', 
               unemp.diff='Change in Unemployment rate', log.ip='100 * Log Industrial Production',
               ind.prod='Industrial production', spf.fcast='SPF inflation forecast', 
               log.gdp='100 * Log GDP', inf.gdp='GDP deflator growth', log.inv='100 * Log investment', 
               log.cons='100 * Log Consumption', 
               inf.cpi.a='Realized inflation, current month',
               inf.gdp.a='Realized inflation GDP deflator growth, current month', 
               inf.fire='Realized inflation, one year ahead', 
               inf.sentiment='Inflation sentiment',
               i.3.mo='3-month treasury rate', i.1.yr='1-year treasury rate',
               i.2.yr='2-year treasury rate', i.5.yr='5-year treasury rate',
               i.10.yr='10-year treasury rate', i.20.yr='20-year treasury rate', i.30.yr='30-year treasury rate',
               log.m1='100 * log M1', log.m2='100 * log M2', log.currency='100 * log currency', 
               log.bank.credit='100 * log bank credit', leverage.idx='Leverage index', 
               log.wk.hrs='100 * Log work hours', log.vehicles='100 * Log vehicle sales',
               log.emp='100 * Log employment', log.housing.starts='100 * Log housing Starts',
               log.r.oil.r='100 * Log real oil price', g.surp.idx='Primary surplus index', 
               log.will.idx='100 * Log Wilshire 5000 index', log.fx.cad='100 * Log USD-CAD exch. rate',
               log.fx.jpn='100 * Log USD-JPY exch. rate', log.fx.gbr='100 * Log USD-GBP exch. rate' )

l.outcomes <- list( base=c(fcast, inf, 'fed.funds.rate', 'log.ip' ),
                    int.rates=c('fed.funds.rate', 'i.1.mo', 'i.3.mo', 'i.1.yr', 'i.2.yr', 'i.5.yr', 'i.10.yr', 'i.20.yr', 'i.30.yr'),
                    money.credit=c('log.m1', 'log.m2', 'log.currency', 'log.bank.credit','leverage.idx', paste0(inf, '.a') ),
                    real=c('log.vehicles', 'unemp', 'log.wk.hrs', 'log.emp', 'log.ip', 'log.housing.starts', 'log.r.oil.r'),
                    financial=c('g.surp.idx', 'log.will.idx', 'log.fx.cad', 'log.fx.gbr', 'log.fx.jpn' ) )

# int.rates=c('fed.funds.rate', 'i.3.mo', 'i.2.yr', 'i.5.yr', 'i.20.yr', 'i.30.yr', 'i.10.yr'),
# money.credit=c('log.m1', 'log.m2', 'log.currency', 'log.bank.credit','leverage.idx', 'inf.a'),
# real=c('log.wk.hrs', 'unemp', 'log.vehicles', 'log.emp', 'log.ip', 'log.housing.starts', 'log.r.oil.r'),
# financial=c('g.surp.idx', 'log.will.idx', 'log.fx.cad', 'log.fx.gbr', 'log.fx.jpn' )




pd <- if(freq=='q') 'quarter' else 'mon'

gg.ts.data <- 
    ggplot( df %>% filter(variable %in% names(var.labs)) %>% 
              gather(seas, value, -date, -variable, -pd ),
            aes(x=date, y=value, group=seas, color=seas)) +
      geom_line(lwd=.9) +
      facet_wrap(~variable, scale='free_y', label=labeller( variable=var.labs ) ) +
      theme_minimal() +
      scale_color_manual( labels=c( 'Raw data', 'Non-seasonal component'), values=c('blue', 'red') ) +
      labs( color='Type', y='Percent') +
      theme( legend.position = 'bottom' )
ggsave( paste0('graphs/time_series_', freq, '.pdf'), gg.ts.data, height=10, width=10 )

gg.ts.data.ds <- 
  ggplot( df %>% filter(variable %in% names(var.labs)),
          aes(x=date, y=value.deseas)) +
  geom_line(lwd=.9) +
  facet_wrap(~variable, scale='free_y', label=labeller( variable=var.labs ) ) +
  theme_minimal() +
  scale_color_manual( labels=c( 'Raw data', 'Non-seasonal component'), values=c('blue', 'red') ) +
  labs( color='Type', y='Percent') +
  theme( legend.position = 'bottom' )
ggsave( paste0('graphs/time_series_deseas_', init.yr, '_', freq,  '.pdf'), gg.ts.data.ds, height=10, width=10 )

if(inf=='michigan.fcast' ){
  for( gp in names(l.outcomes) ){
    
    this.gg.ts.data <- 
      ggplot( df %>% filter(variable %in% l.outcomes[[gp]]) %>% 
                gather(seas, value, -date, -variable, -pd ),
              aes(x=date, y=value, group=seas, color=seas, lty=seas)) +
      geom_line(lwd=.9) +
      facet_wrap(~variable, scale='free_y', label=labeller( variable=var.labs ) ) +
      theme_minimal() +
      scale_color_discrete( labels=c( 'Raw data', 'Non-seasonal component')) + 
      scale_linetype_discrete( labels=c( 'Raw data', 'Non-seasonal component')) + 
      labs( color='Type', linetype='Type', y='Percent', x='Date') +
      geom_hline(aes(yintercept=0), lwd=.5) +
      theme( legend.position = 'bottom' )
    ggsave( paste0('graphs/time_series_', freq, '_', gp %>% gsub('\\.','_',.), '.pdf'), this.gg.ts.data, height=6, width=10 )
    
    gg.ts.data.ds <- 
      ggplot( df %>% filter(variable %in% l.outcomes[[gp]]),
              aes(x=date, y=value.deseas)) +
      geom_line(lwd=.9) +
      facet_wrap(~variable, scale='free_y', label=labeller( variable=var.labs ) ) +
      theme_minimal() +
      scale_color_manual( labels=c( 'Raw data', 'Non-seasonal component'), values=c('blue', 'red') ) +
      labs( color='Type', y='Percent') +
      geom_hline(aes(yintercept=0), lwd=.5) +
      theme( legend.position = 'bottom' )
    ggsave( paste0('graphs/time_series_deseas_', init.yr, '_', freq, '_', gp %>% gsub('\\.','_',.),  '.pdf'), gg.ts.data.ds, height=6, width=10 )
  }    
}


#### 2. Plot the IRFs ###
fcast.var.name <- fcast %>% str_split(.,'\\.') %>% unlist %>% nth(1)

## 2.1 Reduced form ##
df.irf.rf <- make.irf.rf(l.var.coefs, n.pds = irf.pds )
gg.irfs.rf <- ggplot( df.irf.rf ) +
                      geom_path( aes(x=period, y=value), lwd=.9) +
                      geom_ribbon( data = est.bootstrap$reduced.form, aes(x=period, ymin=q.05, ymax=q.95 ), alpha=.25 ) +
                      facet_grid(rows = vars(shock), cols=vars(outcome), label=labeller( shock=var.labs, outcome=var.labs )) +
                      theme_minimal() +
                      labs( title=paste0('Reduced form impulse responses, ', l.var.coefs$lags, ' lags') ) +
                      xlab('Period') + ylab('Percent') +
                      xlim(c(0,irf.plot.pds))
ggsave( paste0( 'graphs/', fcast.var.name, '_irf_rf_', init.yr, '_', freq, '_', l.var.coefs$lags, '_lags.pdf'), gg.irfs.rf, height = 10, width = 10)

## 2.2 Structural ##
df.irf.struct <- make.irf.struct(l.var.coefs, est.A$A, fcast.horiz=fcast.horiz, inf.name=inf, n.pds = irf.pds, fcast = fcast )
other.vars <- df.irf.struct %>% pull(outcome) %>% unique %>% .[!(.==fcast)]
df.irf.struct <- df.irf.struct %>% mutate( outcome.f=factor( outcome, levels=c(fcast,other.vars) ) )
gg.irfs.struct <- ggplot( df.irf.struct ) +
                          geom_path(lwd=.9, aes(x=period, y=value)) +
                          geom_ribbon( data = est.bootstrap$structural %>% 
                                         mutate( outcome.f=factor( outcome, levels=c(fcast,other.vars) ) ),
                                       aes(x=period, ymin=q.05, ymax=q.95 ), alpha=.25 ) +
                          facet_grid(rows = vars(shock), cols=vars(outcome.f), label=labeller( outcome.f=var.labs )) +
                          theme_minimal() +
                          xlim(c(0,irf.plot.pds)) +
                          labs( title=paste0('Structural impulse responses, ', l.var.coefs$lags, ' lags') ) +
                          xlab('Period') + ylab('Percent')
ggsave( paste0( 'graphs/', fcast.var.name, '_irf_struct_', init.yr, '_', freq, '_', l.var.coefs$lags, '_lags.pdf'), gg.irfs.struct, height = 10, width = 10)

irf.ylim <- if(freq=='m') c(-.8, .4) else c(-2,2)
inf.ann <- if(freq=='m') function(x) x*12 else function(x) x*4
# inf.12m <- if(freq=='m') function(x) rollsum( c( rep( 0,11), x), 12 ) else function(x) rollsum( c( rep( 0,3), x), 4 )

df.irf.nf <- df.irf.struct %>% filter(shock=='Non-fundamental') %>% 
  mutate(value=ifelse(outcome==inf,inf.ann(value), value),
         outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor,
         outcome.f = fct_relevel( outcome.f, c(fcast, 'inf.fire', 'inf.sentiment', paste0(inf, '.a'), y ) ) ) # %>%
  # full_join( {.} %>% filter(outcome==inf) %>% group_by(shock, outcome, outcome.f) %>%
  #              mutate( outcome='inf.12m', outcome.f='inf.12m', value=inf.12m(value) ) %>%
  #              ungroup ) %>%
  # arrange( shock, outcome, period )
gg.irfs.struct.nf <- ggplot( df.irf.nf) +
  geom_path(lwd=.9, aes(x=period, y=value)) +
  geom_ribbon( data = est.bootstrap$structural %>% filter(shock=='Non-fundamental') %>% 
                 mutate( outcome.f=factor( outcome, levels=c(fcast,other.vars) ),
                         q.05=ifelse(outcome==inf,inf.ann(q.05), q.05),
                         q.95=ifelse(outcome==inf,inf.ann(q.95), q.95),
                         outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor ),
               aes(x=period, ymin=q.05, ymax=q.95 ), alpha=.25 ) +
  geom_hline(aes(yintercept=0), lwd=.5) +
  facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ), scales='free_y') +
  # xlim(c(0,irf.plot.pds)) +
  theme_minimal() + # ylim(irf.ylim) +
  # labs( title=paste0('Structural impulse responses to non-fundamental shock only, ', l.var.coefs$lags, ' lags') ) +
  xlab('Horizon') + ylab('Percent points') +
  scale_x_continuous( breaks=seq(0,irf.plot.pds,6), limits = c(0,irf.plot.pds) )
gg.irfs.struct.nf %>% print
ggsave( paste0( 'graphs/', fcast.var.name, '_irf_struct_nf_', init.yr, '_', freq, '_', l.var.coefs$lags, '_lags.pdf'), 
        gg.irfs.struct.nf, height = 8, width = 10)

df.var.lp <- left_join( df.irf.nf %>% rename( var=value), 
                        est.lp %>% rename( lp=value) ) %>%
  mutate(lp=ifelse(outcome==inf,inf.ann(lp), lp)) %>%
  gather( est.type, value, -shock, -outcome, -period, -outcome.f) %>%
  mutate( est.type=ifelse(est.type=='var', 'VAR', 'Local projection')) %>%
  as_tibble()
gg.irfs.var.lp <- ggplot( df.var.lp, aes(x=period, y=value, group=est.type,
                                         color=est.type, shape=est.type)) +
    geom_path(lwd=.9) +
    geom_point(size=3) +
    geom_hline(aes(yintercept=0), lwd=.5) +
    facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ), scales = 'free_y') +
    theme_minimal() + # ylim(irf.ylim) +
    # labs( title=paste0('Structural impulse responses to non-fundamental shock only, ', l.var.coefs$lags, ' lags') ) +
    xlab('Horizon') + # ylab('Percent') +
    theme(legend.position = 'bottom') +
    labs(color='Estimation method', shape='Estimation method') +
    scale_x_continuous( breaks=seq(0,irf.plot.pds,6), limits = c(0,irf.plot.pds) )
gg.irfs.var.lp %>% print
ggsave( paste0( 'graphs/', fcast.var.name, '_irf_var_lp_', init.yr, '_', freq, '_', l.var.coefs$lags, '_lags.pdf'), gg.irfs.var.lp, height = 10, width = 10)  


#### 3. Plot the variance decomposition ####
df.var.decomp <- 
  suppressMessages(
  lapply( 1:length(est.var.decomp$decomp.ratio), 
        function(i) est.var.decomp$decomp.ratio[[i]] %>% 
          as.data.frame %>%
          rownames_to_column('outcome') %>%
          gather( shock, value, -outcome ) %>%
          mutate( shock = ifelse(shock=='Non-fundamental', ' Sentiment', 'Fundamental')) %>%
          group_by( outcome, shock ) %>%
          summarise(value=sum(value)) %>%
          ungroup %>%
          mutate( horizon=i ) ) %>%
  reduce(full_join) %>%
  as_tibble() %>%
  select( outcome, shock, horizon, value ) %>%
    mutate(outcome.f = fct_relevel( outcome %>% as.factor, c(fcast, paste0(inf, '.a'), y ) )) %>%
  arrange( outcome, shock, horizon ) )
gg.var.decomp <- ggplot( df.var.decomp, aes( group=shock ) ) +
                  geom_line(lwd=.9, aes(x=horizon, y=value, color=shock ) ) +
                  geom_point(size=3, aes(x=horizon, y=value, color=shock, shape=shock ) ) +
                  geom_ribbon( data=est.bootstrap$var.decomp %>% 
                                 mutate(outcome.f=outcome%>% as_factor,
                                        shock = ifelse(shock=='Non-fundamental', ' Sentiment', 'Fundamental') ), 
                               aes( x=horizon, ymin=q.05, ymax=q.95, fill=shock ), alpha=.25 ) +
                  facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ) ) +
                  theme_minimal() +
                  theme(legend.position = 'bottom') +
                  # xlim(c(0,irf.plot.pds)) +
                  labs(color='Shocks', shape='Shocks') + # , title=paste0('Structural variance decomposition, ', l.var.coefs$lags, ' lags') ) +
                  xlab('Horizon') + guides(fill='none') +
                  scale_x_continuous( breaks=seq(0,irf.plot.pds,6), limits = c(0,irf.plot.pds) ) +
                  ylim(c(0,1)) + ylab('Fraction of variance')
ggsave( paste0( 'graphs/', fcast.var.name, '_irf_var_decomp_', l.var.coefs$lags, '_lags.pdf'), gg.var.decomp, height = 6, width = 10)


save( df, df.irf.rf, df.irf.struct, df.var.decomp, est.bootstrap,
      file=paste0( 'data/', fcast.var.name, '_', init.yr, '_', freq, '_', l.var.coefs$lags, '.rdata' ) )

#### 4. The sentiment shock itself ####
struct.resid <- solve( est.A$A, l.var.coefs$var %>% resid() %>% t ) %>% t
df.struct.resid <- data.frame( date = df$date %>% unique() %>% sort, 
                               rbind( matrix( NA, nrow=l.var.coefs$lags, ncol=est.A$A%>%ncol ),
                                      struct.resid ) )
names(df.struct.resid) <- c( 'date', 'Non-fundamental', 
                             paste0( 'Non-fundamental #', 1:(ncol(df.struct.resid)-2) ) )
df.struct.resid.long <- df.struct.resid %>% 
  gather(shock, value, -date) %>% 
  group_by(shock) %>%
  mutate( value.12m=rollmean(value, 12, fill=NA, align='r' ) )
gg.sentiment <- ggplot( df.struct.resid.long %>% filter( shock=='Non-fundamental') %>%
                          gather( type, value, -date, -shock) %>% 
                          mutate( type= ifelse(type=='value', ' Shock', '12-month rolling average') %>%
                                    as.factor()), 
                        aes( x=date, y=`value`, group=type, color=type, size=type ) ) +
  geom_line(lwd=.9)+
  geom_hline(aes(yintercept=0)) +
  theme_minimal() +
  xlab('') +
  scale_color_manual(values=c('lightgrey',"black")) +
  scale_size_manual(values=c(1,1)) +
  ylab('Inflation sentiment shock') +
  theme( legend.position = 'bottom' ) +
  labs(color=NULL)
ggsave( paste0( 'graphs/', fcast.var.name, '_sentiment_shk_', l.var.coefs$lags, '_lags.pdf'),
        gg.sentiment, height = 5, width = 10)

#### 5. The rolling regressions ####
make.roll.chart <- function( df.roll, date.var, xlab, df.full ){
# Make the rolling window chart
    
  df.cht <- df.roll %>% 
    select( outcome, date.var, q.05, q.50, q.95 ) %>%
    group_by(outcome) %>%
    left_join(df.full) %>%
    mutate( q.05=ifelse(outcome==inf,inf.ann(q.05), q.05),
            q.50=ifelse(outcome==inf,inf.ann(q.50), q.50),
            q.95=ifelse(outcome==inf,inf.ann(q.95), q.95),
            q.50.full=ifelse(outcome==inf,inf.ann(q.50.full), q.50.full),
            q.50.avg=mean(q.50, na.rm=T),
            outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor,
            outcome.f = fct_relevel( outcome.f, c(fcast, 'inf.fire', 'inf.sentiment', paste0(inf, '.a'), y ) ) )
    # The chart data
  gg.out <- ggplot(df.cht, aes_string(x=date.var) ) +
    geom_path( aes(y=q.50), lwd=1.1) +
    geom_path( aes(y=q.50.full), lwd=.9, lty=3) +
    geom_path( aes(y=q.50.avg), lwd=.9, lty=2, color='blue') +
    geom_ribbon( aes(ymin=q.05, ymax=q.95 ), alpha=.25 ) +
    geom_hline(aes(yintercept=0), lwd=.5) +
    facet_wrap( ~outcome.f, scales='free_y', label=labeller( outcome.f=var.labs )) +
    theme_minimal() +
    ylab('') +
    xlab(xlab)
  
  return(gg.out)
}

if( exists('df.robust.end') & robust){
  df.full <- df.robust.end %>%
    group_by(outcome) %>% 
    summarise( q.50.full=q.50[final.date==max(final.date)] )
  gg.robust.end <- make.roll.chart( df.robust.end, 'final.date', 'Final date', df.full )
  ggsave( paste0( 'graphs/', fcast.var.name, '_irf_var_decomp_', l.var.coefs$lags,
                  '_lags_roll_end.pdf'), gg.robust.end, height = 8, width = 10)
  gg.robust.start <- make.roll.chart( df.robust.start, 'init.date', 'Initial date', df.full )
  ggsave( paste0( 'graphs/', fcast.var.name, '_irf_var_decomp_', l.var.coefs$lags,
                  '_lags_roll_start.pdf'), gg.robust.start, height = 8, width = 10)
  gg.robust.roll <- make.roll.chart( df.robust.roll, 'final.date', 'Final date', df.full )
  ggsave( paste0( 'graphs/', fcast.var.name, '_irf_var_decomp_', l.var.coefs$lags,
                  '_lags_roll_both.pdf'), gg.robust.roll, height = 8, width = 10)
}


#### 6. The Machine-Learning VARs ####
l.outcomes$base <- c(fcast, 'inf.fire', 'inf.sentiment', paste0(inf, '.a'), 'fed.funds.rate', 'log.ip' )
  # Redefine for prettiness
if(exists('df.big.irf.struct.full') & robust){
    df.big.irf.nf <- df.big.irf.struct.full %>% filter(shock=='Non-fundamental') %>% 
      mutate(value=ifelse(outcome==inf,inf.ann(value), value),
             outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor ) %>%
      full_join( df.irf.nf %>% mutate(var.method=' Baseline') )
  for(this.outcomes in names(l.outcomes)){
    df.big.irf.nf <- df.big.irf.nf %>%
      mutate( outcome.f = fct_relevel( outcome.f, l.outcomes[[this.outcomes]] ) ) 
    gg.big.irfs.struct.nf <- 
      ggplot( df.big.irf.nf %>% filter( outcome.f %in% l.outcomes[[this.outcomes]] ),
              aes(x=period, y=value, group=var.method, color=var.method, shape=var.method ) ) +
      geom_path(lwd=.9) +
      geom_point(size=2) +
      geom_hline(aes(yintercept=0), lwd=.5) +
      facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ), scales='free_y') +
      theme_minimal() + # ylim(irf.ylim) +
      xlab('Horizon') + ylab('') +
      scale_x_continuous( breaks=seq(0,irf.plot.pds,6), limits = c(0,irf.plot.pds) ) +
      theme(legend.position = 'bottom') +
      labs(color='Specification', shape='Specification')
    gg.big.irfs.struct.nf %>% print
    ggsave( paste0( 'graphs/', fcast.var.name, '_irf_struct_nf_', l.var.coefs$lags,
                    '_lags_ML_', this.outcomes, '.pdf'), gg.big.irfs.struct.nf, height = 6, width = 10)
  }
}

if(exists('df.favar.irf.struct.full') & robust){
  df.favar.irf.nf <- df.favar.irf.struct.full %>% filter(shock=='Non-fundamental') %>% 
    mutate(value=ifelse(outcome==inf,inf.ann(value), value),
           outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor ) %>%
    full_join( df.irf.nf %>% mutate(var.method='Baseline') ) %>%
    filter( !str_detect( outcome, 'PC' ) ) %>%
    mutate( outcome.f = fct_relevel( outcome.f, l.outcomes[[1]] ),
            var.method = fct_relevel( var.method, c( 'Baseline', paste0( n.favar, ' component FAVAR' ) ) ) ) 
  gg.favar.irfs.struct.nf <- 
      ggplot( df.favar.irf.nf %>% filter( outcome.f %in% l.outcomes[[1]] ),
              aes(x=period, y=value, group=var.method, color=var.method, shape=var.method ) ) +
      geom_path(lwd=.9) +
      geom_point(size=2) +
      geom_hline(aes(yintercept=0), lwd=.5) +
      facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ), scales='free_y') +
      theme_minimal() + # ylim(irf.ylim) +
      xlab('Horizon') + ylab('') +
      scale_x_continuous( breaks=seq(0,irf.plot.pds,6), limits = c(0,irf.plot.pds) ) +
      theme(legend.position = 'bottom') +
      labs(color='Specification', shape='Specification')
    gg.favar.irfs.struct.nf %>% print
    ggsave( paste0( 'graphs/', fcast.var.name, '_irf_struct_nf_', l.var.coefs$lags,
                    '_lags_FAVAR.pdf'), gg.favar.irfs.struct.nf, height = 6, width = 10)

  df.favar.boot.full <- est.bootstrap$structural %>%
    filter(period==0, shock=='Non-fundamental') %>%
    select(-period) %>%
    ungroup() %>%
    mutate( var.method='Baseline' ) %>%
    select( outcome, var.method, everything(), -shock ) %>%
    full_join( df.favar.boot ) %>%
    mutate(outcome.f=ifelse(outcome==inf,paste0(inf,'.a'),outcome) %>% as.factor %>%
             fct_relevel( l.outcomes[[1]] ),
           var.method = fct_relevel( var.method, c( 'Baseline', paste0( n.favar, ' component FAVAR' ) ) ) )
  gg.favar.sig.struct.nf <- 
      ggplot( df.favar.boot.full %>% filter( outcome.f %in% l.outcomes[[1]] ),
              aes(x=var.method, group=var.method, color=var.method, shape=var.method ) ) +
      geom_point(size=2, aes(y=q.50)) +
      geom_errorbar(aes(ymin = q.05, ymax = q.95), width = 0.1) +
      geom_hline(aes(yintercept=0), lwd=.5) +
      facet_wrap( ~outcome.f, label=labeller( outcome.f=var.labs ), scales='free_y') +
      theme_minimal() + # ylim(irf.ylim) +
      xlab('') + ylab('') +
      theme(legend.position = 'bottom') +
      labs(color='Specification', shape='Specification') +
      theme(axis.text.x = element_blank())
  gg.favar.sig.struct.nf %>% print
  ggsave( paste0( 'graphs/', fcast.var.name, '_sig_struct_nf_', l.var.coefs$lags,
                    '_lags_FAVAR.pdf'), gg.favar.sig.struct.nf, height = 6, width = 10)
}
