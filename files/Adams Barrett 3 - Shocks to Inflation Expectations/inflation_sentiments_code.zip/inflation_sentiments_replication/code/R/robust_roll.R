##########################################################################################
#
# robust_roll.R
#
# Code to do rolling-window robustness checks for the "Inflation Sentiments" project
# Philip Barrett, Washington DC
# First version: 12mar2022
#
##########################################################################################

min.length <- 120
  # Minimum number of data points for estimation
v.dates <- df$date %>% unique %>% sort()
n.dates <- v.dates %>% length

message('*** Robustness check: rolling start window ***')
for( i.date in 1:(n.dates-min.length)){
  
  this.date <- v.dates[i.date]
  message('   Starting date ', this.date )
  this.df <- df %>% filter( date >= this.date )
  this.l.var.coefs <- make.var( this.df, value.name='value.deseas', var.name='variable', fcast=fcast, inf=inf, y=y, lags = l.var.coefs$lags )
  this.est.phi.h <- make.phi.h( this.l.var.coefs, horiz = fcast.horiz )
  this.est.A <- anc.nlslv( this.l.var.coefs$Sigma, this.est.phi.h )
  this.est.bootstrap <- make.bootstrap( this.l.var.coefs, this.est.A$A, 
                                   fcast.horiz=fcast.horiz, inf.name=inf, n.pds = fcast.horiz, 
                                   var.decomp = FALSE, print.iter=FALSE )
  this.df.struct <- this.est.bootstrap$structural %>%
    filter(period==0, shock=='Non-fundamental') %>%
    select(-period) %>%
    ungroup() %>%
    mutate( init.date=this.date) %>%
    select( outcome, init.date, everything(), -shock )
  df.robust.start <- if(i.date==1) this.df.struct else suppressMessages( full_join(df.robust.start, this.df.struct) )
}
df.robust.start <- df.robust.start %>% arrange(outcome, init.date)

message('*** Robustness check: rolling end window ***')
for( i.date in min.length:n.dates){
  
  this.date <- v.dates[i.date]
  message('   End date ', this.date )
  this.df <- df %>% filter( date <= this.date )
  this.l.var.coefs <- make.var( this.df, value.name='value.deseas', var.name='variable', fcast=fcast, inf=inf, y=y, lags = l.var.coefs$lags )
  this.est.phi.h <- make.phi.h( this.l.var.coefs, horiz = fcast.horiz )
  this.est.A <- anc.nlslv( this.l.var.coefs$Sigma, this.est.phi.h )
  this.est.bootstrap <- make.bootstrap( this.l.var.coefs, this.est.A$A, 
                                        fcast.horiz=fcast.horiz, inf.name=inf, n.pds = fcast.horiz, 
                                        var.decomp = FALSE, print.iter=FALSE )
  this.df.struct <- this.est.bootstrap$structural %>%
    filter(period==0, shock=='Non-fundamental') %>%
    select(-period) %>%
    ungroup() %>%
    mutate( final.date=this.date) %>%
    select( outcome, final.date, everything(), -shock )
  df.robust.end <- if(i.date==min.length) this.df.struct else suppressMessages( full_join(df.robust.end, this.df.struct) )
}
df.robust.end <- df.robust.end %>% arrange(outcome, final.date)

message('*** Robustness check: rolling start window ***')
for( i.date in 1:(n.dates-2*min.length)){
  
  this.date.start <- v.dates[i.date]
  this.date.end <- v.dates[i.date + 2*min.length]
  message('   Starting date ', this.date.start )
  message('   End date ', this.date.end )
  this.df <- df %>% filter( date >= this.date.start, date <= this.date.end )
  this.l.var.coefs <- make.var( this.df, value.name='value.deseas', var.name='variable', fcast=fcast, inf=inf, y=y, lags = l.var.coefs$lags )
  this.est.phi.h <- make.phi.h( this.l.var.coefs, horiz = fcast.horiz )
  this.est.A <- anc.nlslv( this.l.var.coefs$Sigma, this.est.phi.h )
  this.est.bootstrap <- make.bootstrap( this.l.var.coefs, this.est.A$A, 
                                        fcast.horiz=fcast.horiz, inf.name=inf, n.pds = fcast.horiz, 
                                        var.decomp = FALSE, print.iter=FALSE )
  this.df.struct <- this.est.bootstrap$structural %>%
    filter(period==0, shock=='Non-fundamental') %>%
    select(-period) %>%
    ungroup() %>%
    mutate( init.date=this.date.start, final.date=this.date.end ) %>%
    select( outcome, init.date, final.date, everything(), -shock )
  df.robust.roll <- if(i.date==1) this.df.struct else suppressMessages( full_join(df.robust.roll, this.df.struct) )
}
df.robust.roll <- df.robust.roll %>% arrange(outcome, init.date)

save( df.robust.start, df.robust.end, df.robust.roll,
      file=paste0( 'data/', fcast.var.name, '_', init.yr, '_', freq, '_', l.var.coefs$lags, '_roll.rdata' ) )
